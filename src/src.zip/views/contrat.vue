<template>
  <v-container fluid>
    <v-card flat>
      <v-tabs>
        <v-tab class="white black--text">
          <v-icon color="black" left> mdi-finance </v-icon>
          Référentiel
        </v-tab>
        <v-tab class="white black--text">
          <v-icon color="black" left> mdi-finance </v-icon>
          Procès-verbal
        </v-tab>
        <v-tab class="white black--text">
          <v-icon color="black" left> mdi-ambulance </v-icon>
          Fmp
        </v-tab>
        <v-tab class="white black--text">
          <v-icon color="black" left> mdi-access-point </v-icon>
          Recours
        </v-tab>
        <v-tab-item key="1">
          <v-card flat>

          </v-card>
        </v-tab-item>
        <v-tab-item key="2">
          <v-card flat>

          </v-card>
        </v-tab-item>
        <v-tab-item key="3">
          <v-card flat>

          </v-card>
        </v-tab-item>
        <v-tab-item key="4">

        </v-tab-item>
      </v-tabs>
    </v-card>
  </v-container>
</template>
<script>
// import ChartCall from "../components/Commerciale/appel.vue";
// import ChartRdv from "../components/Commerciale/rdv.vue";
// import ChartClient from "../components/Commerciale/client.vue";
// import ChartProspect from "../components/Commerciale/prospect.vue";
// import ChartCotation from "../components/production/cotation.vue";
// import ChartCourrier from "../components/Commerciale/courrier.vue";
// import ChartEmission from "../components/production/emission.vue";
// import chartEncaissement from "../components/production/encaissement.vue";
// import chartCoassurance from "../components/production/coassurance.vue";
// import chartRegulation from "../components/production/regul.vue";
// import chartpb from "../components/production/participation.vue";
// import chartReassure from "../components/production/reassur.vue";
// import chartInventaire from "../components/sinistre/inventaire.vue";
// import chartSinistre from "../components/sinistre/sinistre.vue";
// import chartPv from "../components/sinistre/pv.vue";
// import chartBon from "../components/sinistre/bon.vue";
// import chartExpertise from "../components/sinistre/expertise.vue";
// import chartOffres from "../components/sinistre/offres.vue";
// import chartPaiement from "../components/production/paiement.vue";
// import chartecheance from "../components/production/echeance.vue";
// import recapAll from "../components/recap/recap.vue";
// import recapAsk from "../components/recap/recapAsk.vue";
// import Impayer from "../components/production/impayer.vue";

export default {
  name: "contratComponent",
  components: {
    // recapAll,
    // ChartCall,
    // ChartRdv,
    // ChartClient,
    // ChartProspect,
    // ChartCotation,
    // ChartCourrier,
    // ChartEmission,
    // chartEncaissement,
    // chartCoassurance,
    // chartRegulation,
    // chartpb,
    // chartReassure,
    // chartSinistre,
    // chartPv,
    // chartBon,
    // chartExpertise,
    // chartOffres,
    // chartInventaire,
    // chartPaiement,
    // Impayer,
    // chartecheance,
    // recapAsk,
  },
};
</script>
